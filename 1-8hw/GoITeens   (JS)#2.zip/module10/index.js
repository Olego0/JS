'use strict';
const obj = {   
    name: "valentin",
    male: "male",
    isActive: true,
    age: 29
};
const str = JSON.stringify(obj);
console.log(obj);
console.log(str);
const notStr = JSON.parse(str);
console.log(notStr);

localStorage.setItem("user", str);

const num = localStorage.getItem("txt");
console.log(num);

localStorage.removeItem("user");

