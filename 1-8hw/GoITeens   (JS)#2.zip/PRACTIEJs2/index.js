"use strict";
// const arr = ["a","b","c","d"];
// arr.forEach((el, index) => console.log((`${index}=${el}`)));


// const user = {
//     name: "Petia",
//     age: 29,
//     gender: "male",
//     isWorking: true
// }
// user.hasPet = true;
// user.isWorking = false;
// delete user.gender;
// console.log(Object.keys(user).length);
// for (const key in user) {
//     console.log(`${key} = ${user[key]}`);
// };



// let arr = [];
// let messege;
// do{
//     messege = prompt("enter number") 
//     arr.push(Number(messege));
// } while (!messege !== null);
// const sum = arr.reduce((acc, el)=> acc += el, 0);
// console.log(sum);

// const arr = ["oleg", "klark", "dan"];
// arr.unshift = ("nikita");
// arr.pop()
// arr.shift()
// console.log(arr);


// const str = "hello my mame is _.oleeehh._";
// const arr = str.split(" ");
// console.log(arr.length);
// const newArr = arr.slice();


// const arr = [
//     {
//         name: "a",
//         age: 100
//     },
//     {
//         name: "b",
//         age: 3
//     },
//     {
//         name: "c",
//         age: 1
//     }
// ];
// const newArr = arr.filter(el => el.age > 1);
// console.log(newArr);

// const sum = arr.reduce((acc, el)=> acc += el.age, 0);
// console.log(sum);

// const year = arr.find(el => el.age === 100);
// console.log(year);

// const age = arr.map(el => el.age * 2);
// console.log(age);
// /////////////////////////////////////////////////////////////
// let messege = prompt("password, please");
// const arr = ["qwerty", "mango", "chicken"];
// const validation = function(values){
//     if(values.length > 4){
//         return true;
//     } else {
//         return false; 
//     }
// }
// const pass = function(corect){
//     if (arr.includes(corect)) {
//         return true;
//     } else{
//         return false;
//     }
// }
// const final = function(messege){
//     if(validation(messege)){
//         if(pass(messege)){
//             return alert("Welcome!!1")
//         } else{
//             return alert("Incorect password")
//         }
//     }else{
//         return alert("password is to short")
//     }
// }
// final(messege);
// /////////////////////////////////////////////////////
// const arr = [
//     {
//         name: "apple",
//         price: 10
//     },
//     {
//         name: "pineple",
//         price: 30
//     },
//     {
//         name: "potato",
//         price: 15
//     },
//     {
//         name: "lemon",
//         price: 10
//     },
//     {
//         name: "orange",
//         price: 25
//     }
// ]
// const list = document.querySelector("#list");
// const str = arr.reduce((acc, el) => acc += `<li><h2>${el.name}</h2><p>${el.price}</p></li>`, "")
// list.innerHTML = str;
//////////////////////////////////////////////////////////////////////////////////

const control = document.querySelector("#control");
// const incris = (value) => value += 1;
// const decris = (value) => value -= 1;
const g = function(e){
    console.log(e.target.dataset.control);
    
    if (e.target.dataset.control === "decris") {
        control.children[1].textContent = Number(control.children[1].textContent ) - 1;
    }else if(e.target.dataset.control === "incris"){
        control.children[1].textContent = Number(control.children[1].textContent ) + 1;
    }else {
        return;
    }
}
control.addEventListener("click", g);
console.log(control.children[1].textContent);

