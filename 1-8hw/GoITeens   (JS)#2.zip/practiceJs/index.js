"use strict";
const controls = document.querySelector("#controls");
const boxes = document.querySelector("#boxes");
const randomm = () => Math.round(Math.random() * 255);
function createBoxes(amount) {
    let values = 30;
    for (let i = 0; i < amount; i++) {
        const div = document.createElement("div");
        
        values += 10;
        div.style.backgroundColor = `rgb(${randomm()}, ${randomm()}, ${randomm()})`;
        div.style.height = `${values}px`;
        div.style.width = `${values}px`;
        boxes.append(div);
        
    };
};
// console.log(randomm());
function eventHandler(event){
    if (event.target.dataset.action === "render") {
        createBoxes(+controls.firstElementChild.value);
        console.log("aasdd");
        
    }
    else if(event.target.dataset.action === "destroy"){
        boxes.innerHTML = "";
    }
};
controls.addEventListener("click", eventHandler);


