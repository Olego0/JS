"use strict";
// document.body.style.background = "red";
const image = document.querySelector("image");
console.log(image.attributes);
console.log(image.getattributes("alt"));
console.log(image.hasAttribute("src"));






