"use strict";
const div = document.querySelector("#button")
const btn = document.querySelector("button")
btn.textContent = 'Click me';
div.append(btn)