"use strict";

const scientist = [
    {
      first: "Albert",
      last: "Einstein",
      year: 1879,
      passed: 1955
    },
    {
      first: "Isaac",
      last: "Newton",
      year: 1643,
      passed: 1727
    },
    {
      first: "Galileo",
      last: "Galilei",
      year: 1564,
      passed: 1642
    },
    {
      first: "Marie",
      last: "Curie",
      year: 1867,
      passed: 1934
    },
    {
      first: "Johannes",
      last: "Kepler",
      year: 1571,
      passed: 1630
    },
    {
      first: "Nicolaus",
      last: "Copernicus",
      year: 1473,
      passed: 1543
    },
    {
      first: "Max",
      last: "Planck",
      year: 1858,
      passed: 1947
    },
    {
      first: "Katherine",
      last: "Blodgett",
      year: 1898,
      passed: 1979
    },
    {
      first: "Ada",
      last: "Lovelace",
      year: 1815,
      passed: 1852
    },
    {
      first: "Sarah E.",
      last: "Goode",
      year: 1855,
      passed: 1905
    },
    {
      first: "Lise",
      last: "Meitner",
      year: 1878,
      passed: 1968
    },
    {
      first: "Hanna",
      last: "Hammarström",
      year: 1829,
      passed: 1909
    }
  ];
  // 1) отримати масив вчених що народилися в 19 ст
  // 2) знайти суму років скільки прожили всі вченні
  // 3) Відсортувати вчених по алфавіту
  // 4) Відсортувати вчених по даті народження
  // 5) Відсортувати вчених по кількості прожитих років
  // 6) Видалити з масива вчених що родилися в 15 або 16 або 17 столітті
  // 7) Знайти вченого який народився найпізніше.
  // 8) Знайти рік народження Albert Einstein
  // 9) Знайти вчених прізвище яких починається на літеру С
  // 10) Видалити з масива всіх вчених імя яких починається на A

//+++++++++++++++++++++++++++1+++++++++++++++++++++++++
// const filter = scientist.filter(el => el.year <= 1800 && el.year < 1900 )
const filter = scientist.filter(el => el.year >= 1800 && el.year < 1900);
console.log(filter);


//+++++++++++++++++++++++++++2+++++++++++++++++++++++++
// for (const arr in scientist) {
//   const map = scientist.map(el => el.year + el.year);
// }
// console.log(map);
// const gamma = scientist.map(el => el.passed - el.year);
// console.log(gamma);


//+++++++++++++++++++++++++++3+++++++++++++++++++++++++
// const alpha = scientist.sort((lastOne, nextOne) => {
   
//   return lastOne.first > nextOne.first ? -1 : 1;
// });
// console.log(alpha);


//+++++++++++++++++++++++++++4+++++++++++++++++++++++++
// const beta = scientist.sort((qwerty , qwertyqwerty) => {

//   return qwerty.year < qwertyqwerty.year ? 2 : -2;
// });
// console.log(beta);


//+++++++++++++++++++++++++++5+++++++++++++++++++++++++
// const gamma = scientist.map(el => el.passed - el.year);
// console.log(gamma);
//         // const gamma2 = gamma.sort((lastThree, nextThree) => {
//         //   return lastThree.gamma > Three.gamma ? 1 : -1;
//         // })
// console.log(gamma.sort());

// +++++++++++++++++++5(mihael)+++++++++++++++++++++++
// const lived = scientist.sort((a, b) => {
//   const lastOne = a.passed - a.year
//   const nextOne = b.passed - b.year
 
//   return lastOne > nextOne ? 1 : -1;});
// console.log(lived);


//+++++++++++++++++++++++++++6+++++++++++++++++++++++++
const delta = scientist.filter(el => el.year > 1700);
console.log(delta);
// const deltaTwo = scientist.splice(delta);
// console.log(scientist);
// console.log(deltaTwo);



//+++++++++++++++++++++++++++7+++++++++++++++++++++++++
// const zero = 0;
// const epsilon = scientist.find(el => el.year > )
// console.log(epsilon);


//+++++++++++++++++++++++++++8+++++++++++++++++++++++++
const zeta = scientist.find(el => el.first === "Albert");
console.log(zeta);


//+++++++++++++++++++++++++++9+++++++++++++++++++++++++
const eta = scientist.filter((lastOne, nextOne) => {
  return lastOne.last === scientist.;
})
console.log(eta);

