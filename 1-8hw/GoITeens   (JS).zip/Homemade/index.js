"use strickt";
document.querySelector("#table");
for (let i = 0; i <= 31; i++) {
    if ((i + 1)%7 == 0) {
        document.write('<td align = "center" bgcolor = "red">' + i + '</td></tr><tr>');
    }
    else if (i%7 == 0){
        document.write('<td align = "center" bgcolor = "red">' + i + '</td></tr><tr>');
    }
    else{
        document.write('<td align = "center">' + i + '</td></tr>');
    }
    
}