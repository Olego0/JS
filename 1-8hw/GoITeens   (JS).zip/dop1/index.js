"use strict";
// const d = [a ,b ,c ,d]
// console.log(d);
//============module2(1)=================
// const logItems = function(Array) {
//     // твой код
//     for (let i = 0; i < Array.length; i++) {
//         const element = logItems[i];
//         // console.log(logItems);
//         console.log(`${i + 1} - ${Array[i]}`);
//     }
//   };
  
//   /*
//    * Вызовы функции для проверки работоспособности твоей реализации.
//    */
//   logItems(['Mango', 'Poly', 'Ajax', 'Lux', 'Jay', 'Kong']);
  
//   logItems([5, 10, 15, 20, 25, 30, 35, 40, 45, 50]);
//============module2(2)=================
const calculateEngravingPrice = function(message, pricePerWord) {
    // твой код
    let arr = message.split(" ");
    let result = pricePerWord * arr.length;
    return result;

  };
  
  /*
   * Вызовы функции для проверки работоспособности твоей реализации.
   */
  console.log(
    calculateEngravingPrice(
      'Proin sociis natoque et magnis parturient montes mus',
      10,
    ),
  ); // 80
  
  console.log(
    calculateEngravingPrice(
      'Proin sociis natoque et magnis parturient montes mus',
      20,
    ),
  ); // 160
  
  console.log(
    calculateEngravingPrice('Donec orci lectus aliquam est magnis', 40),
  ); // 240
  
  console.log(
    calculateEngravingPrice('Donec orci lectus aliquam est magnis', 20),
  ); // 120
//============module2(3)=================
const findLongestWord = function(string) {
    // твой код
    let max = 0;
    let longestWord = (" ");
    let arr = string.split(" ");
    for (let i = 0; i < arr.length; i++) {
      const element = arr[i];
      if (max < arr[i].length){ 
        max = arr[i].length;
        longestWord = arr[i];
      }  
      
      
      
      
    }
    return longestWord;
  };
  
  /*
  * Вызовы функции для проверки работоспособности твоей реализации.
  */
  console.log(findLongestWord('The quick brown fox jumped over the lazy dog')); // 'jumped'
  
  console.log(findLongestWord('Google do a roll')); // 'Google'
  
  console.log(findLongestWord('May the force be with you')); // 'force'
//============module2(4)=================
const formatString = function(string) {
  // твой код

};

/*
 * Вызовы функции для проверки работоспособности твоей реализации.
 */
console.log(formatString('Curabitur ligula sapien, tincidunt non.'));
// вернется оригинальная строка

console.log(formatString('Vestibulum facilisis, purus nec pulvinar iaculis.'));
// вернется форматированная строка

console.log(formatString('Curabitur ligula sapien.'));
// вернется оригинальная строка

console.log(
  formatString(
    'Nunc sed turpis. Curabitur a felis in nunc fringilla tristique.',
  ),
);
// вернется форматированная строка
//================================
// const a = document.querySelector("#touch");
// a.firstElementChild.textContent = "Hello, world";
// a.lastElementChild.style.color = 'red';
//================================
const vegatables = ["cucumber", "potato", "tomato", "corn", "mushroms"];
const b = document.querySelector("#vega");
vegatables.forEach(el => {
const li = document.createElement("li");
li.textContent = el;
b.append(li);
});
//================================

