"use strict";
// const list = document.querySelector("#categories");
// console.log(`в списке ${list.children.length} категорий`);
// Array.from(list.children).forEach(el => {
//     console.log(`катигория : ${el.firstElementChild.textContent}`);
//     console.log(`катигория : ${el.lastElementChild.children.length}`);
    
// })
//=================================================
// const ingredients = [
//     'Картошка',
//     'Грибы',
//     'Чеснок',
//     'Помидоры',
//     'Зелень',
//     'Приправы',
// ];
// const ggg = document.querySelector("#ingredients");
// ingredients.forEach(el => {
//     const li = document.createElement("li");
//     li.textContent = el;
//     ggg.append(li); 
// });

// //===========================3=====================
// const images = [
//     {
//       url:
//         'https://images.pexels.com/photos/140134/pexels-photo-140134.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
//       alt: 'White and Black Long Fur Cat',
//     },
//     {
//       url:
//         'https://images.pexels.com/photos/213399/pexels-photo-213399.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
//       alt: 'Orange and White Koi Fish Near Yellow Koi Fish',
//     },
//     {
//       url:
//         'https://images.pexels.com/photos/219943/pexels-photo-219943.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260',
//       alt: 'Group of Horses Running',
//     },
//   ];
//  const gallery = document.querySelector("#gallery");
//  const image = images.reduce((acc, el) => acc + `<li><img src=${el.url} class = "pic" alt=${el.alt}></li>`, "");
//  gallery.innerHTML = image;
//  const all = document.querySelectorAll(".pic");
//  all.forEach(el => el.style.width = "300px");
//=========================4=============================
// const counterValue = document.querySelector("#value");
// const counter = document.querySelector("#counter");

// const increment = () => counterValue.textContent = Number(counterValue.textContent) + 1;
// const decrement = () => counterValue.textContent = Number(counterValue.textContent) - 1;
// counter.firstElementChild.addEventListener("click", decrement);
// counter.lastElementChild.addEventListener("click", increment);
//========================5==============================
// const ciberCotleta = document.querySelector("#name-input");
// var input = document.body.children[0];
// input.oninput = function() {
//   document.getElementById('name-input').innerHTML = input.value;
// };
const input = document.querySelector("#name-input");
const output = document.querySelector("#name-output");
const name = function(event) {
    if (event.target.value.length === 0) {
        output.textContent = 'незнакомеццццц';
    }
    else{
        output.textContent = event.target.value;
        console.log(event);
    }
}
input.addEventListener('input', name);


